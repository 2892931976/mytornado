
$(function() {
    $('.chart').easyPieChart({
        //your configuration goes here
    });
});